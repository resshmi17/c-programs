#include <stdio.h>

int main() {
    int num1, num2, num3, sum;
    int *ptr;


    printf("Enter three numbers: ");
    scanf("%d %d %d", &num1, &num2, &num3);

    ptr = &num1;

 
    sum = *ptr + *(ptr + 1) + *(ptr + 2);

    
    printf("%d", sum);

    return 0;
}