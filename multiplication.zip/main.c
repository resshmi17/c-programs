#include <stdio.h>

int main()
{
 int i,n;
 scanf("%d",&n);
 for(i=1;i<=5;i++){
     int x=i*n;
     printf("%d * %d= %d\n",i,n,x);
 }
}
