#include<stdio.h>
int main(){
    int r=0,n;
    scanf("%d",&n);
    for(n;n!=0;n=n/10){
        r=r*10+(n%10);
    }
    printf("%d",r);
}
