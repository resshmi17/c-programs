/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int count(int n){
    int count=0;
    while(n){
        
        count++;
        n=n/10;
    }
    return count;
}
int power(int a,int b){
    int t=1;
    while(b--){
        t=t*a;
    }
    return t;
}
int main(){
    int s=0,l,n,t;
    scanf("%d",&n);
    t=n;
    l=count(n);
    
    while(n){
        s=s+power(n%10,l);
        n=n/10;
    }
    printf(s==t?"armstrong":"not an armstrong");
}