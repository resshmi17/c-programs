/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int rev(int n){
    int r=0;
    while(n){
        r=r*10+(n%10);
        n/=10;
    }
    return r;
}
int sqrroot(int m){
    double t=0.0,s=m/2;
    while(t!=s){
        t=s;
        s=(m/t+t)/2;
    }
    return (int)t;
}
int main()
{
    int n,t,s1,s2,s3,s4;
    scanf("%d",&n);
    t=n;
    s1=n*n;
    s2=rev(s1);
    s3=sqrroot(s2);
    s4=rev(s3);
    printf(s4==t?"adam":"not adam");
    return 0;
}

