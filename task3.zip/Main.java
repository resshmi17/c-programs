import java.io.*;
import java.util.*;
public class Main
{
	public static void main(String[] args) throws IOException {
	   BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	   int a=Integer.parseInt(br.readLine());
	   int b=Integer.parseInt(br.readLine());
	   int f,t,g;
	   t=b;
	   for(f=1;b--!=0;f*=a);
	   for(g=1;a--!=0;g*=t);
	   System.out.println(f>g?f:g);
}
}
