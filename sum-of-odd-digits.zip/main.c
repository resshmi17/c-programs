#include<stdio.h>
int main(){
    int n,r=0,c=0,t;
    scanf("%d",&n);
    t=n;
    while(n){
        ++c;
        n=n/10;
    }
    n=t;
    if(c%2!=0){
        while(n){
            r=r+n%10;
            n/=100;
        }
        printf("%d",r);
    }
    else{
        while(n){
            r=r+((n/10)%10);
            n=n/100;
            
        }
        printf("%d",r);
    }
}
