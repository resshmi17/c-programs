/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
char c='B';
int i=7,j=7,k,l,m,n,o;
double x=0.0,y=2.3;
k = ! c;
l = ! (i-j);
m = ! i-j;
n = ! ! (x+y);
o = !x * ! ! y;
printf("%d %d %d %d %d",k,l,m,n,o);
}
