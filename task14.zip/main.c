#include<stdio.h>
int main()
{
int a,i,j,c=1;
scanf("%d",&a);
for(i=1;a>=i;i++)
{
    for(j=1;a>=j;j++)
    {
        j<=a-i?printf(" "):printf("%d ",j%2);
    }
    printf("\n");
}
    return 0;
}