#include <stdio.h>
int rev(int m)
{
    int r=0;
    for( ;m;r=r*10+m%10,m/=10);
    return r;
}
int main()
{
    int n;
    scanf("%d",&n);
    printf(rev(n*n)==rev(n)*rev(n)?"Adam number":"Not a Adam number");
    return 0;
}