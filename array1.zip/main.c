#include <stdio.h>

int main()
{
    int n,flag=0,i;
    scanf("%d",&n);
    int arr[n];
    for(i=0;i<n;i++)
    scanf("%d",&arr[i]);
    for(int i=1;i<n;i++)
    {
        if(arr[i]%2==1 && arr[i-1]%2==1 && arr[i+1]%2==1)
        flag=1;
        
    }
    printf(flag==1?"true":"false");
}