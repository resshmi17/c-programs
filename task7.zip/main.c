#include<stdio.h>
int main(){
    int n,d,p=1,r=0;
    scanf("%d %d",&n,&d);
    while(n){
        if(n%10!=d){
            r=(n%10)*p+r;
            p=p*10;
        }
        
        n=n/10;
    }
    printf("%d",r);
}
