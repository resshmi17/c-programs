/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
float a;
int n;
scanf("%f",&a);
if(a<=100 && a>0){
n=(int)(a);
}
if(n<=100 && n>0){
switch((n-1)/10)
{
    case 0:case 1:case 2:case 3:
    printf("D");break;
    case 4:case 5:
    printf("A");break;
    case 6: case 7:
    printf("B");break;
    case 8: case 9:case 10:
    printf("fail");break;
    default:printf("Invalid");
}

}
else
    printf("Invalid");
}







