#include<stdio.h>
int main(){
    int n,a,b=0;
    scanf("%d",&n);
    while(n){
        a=n%10;
        if(n%2==0)
        b=b+a;
        n=n/10;
    }
    printf("%d",b);
}
