#include <stdio.h>
int rev(int a)
{
   int r=0;
   while(a)
   {
     r=r*10+a%10;
     a/=10;
   }
   return r;
}
 int main()
{
   int n,a[100],i,t=0,j;
   scanf("%d",&n);
   for(i=1;i<=n;i++)
   {
      scanf("%d",&a[i]);
   }
   for(i=1;i<=n;i++)
   {
   for(j=i+1;j<=n;j++)
   {
       if(rev(a[i])>rev(a[j]))
       {
        t=a[j];
        a[j]=a[i];
        a[i]=t;
       }
   }
  }
   for(i=1;i<=n;i++)
   {
      printf("%d ",a[i]);
   }
     return 0;
}