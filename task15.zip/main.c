#include<stdio.h>
int main()
{
int a,i,j,c=1;
scanf("%d",&a);
for(i=1;i<=a;i++)
{
    for(j=1;j<=a;j++)
    {
        if(c==1){
            printf("%-2d ",c++);
        }
        else
            printf("%2d ",i%2?c++:c--);
    }
    c+=i%2?a-1:a+1;
    printf("\n");
}
    return 0;
}
