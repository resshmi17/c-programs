import java.util.*;
import java.io.*;
public class Main
{
	public static void main(String[] args)throws IOException {
		String a= args[0];
		int b=Integer.parseInt(args[1]);
		while(b--!=0){
		   System.out.println(a);
		}
		
	}
}

