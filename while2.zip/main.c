#include<stdio.h>
int main(){
    int i=1,n,a=0,b=0;
    scanf("%d",&n);
    while(i<=n){
        if(i%2==0)
            a=a+i;
        else
            b=b+i;
            i++;
        
    }
    printf("%d",a>b?a-b:b-a);
}