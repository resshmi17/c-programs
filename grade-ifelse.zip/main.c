/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
float n;
scanf("%f",&n);
if(n<=100 && n>=81){
    printf("Fail");
}
else if(n<=80 && n>=61.1){
    printf("B");
}
else if(n<=60 && n>=41.1){
    printf("A");
}
else if(n<=40 && n>=0.1){
    printf("D");
}
else{
    printf("Invalid");
}
}