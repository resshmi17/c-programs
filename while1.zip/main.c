#include<stdio.h>
int main(){
    int i,n;
    scanf("%d",&i);
    while(i>0){
        printf("%d ",i);
        i--;
    }
}
