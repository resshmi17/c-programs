#include<stdio.h>
int main(){
    int n,fact=1,i=1,v=0;
    scanf("%d",&n);
    while(i<=n){
        fact=fact*i;
        v=v+(fact)/i;
        i++;
    }
    printf("%d",v);
}
