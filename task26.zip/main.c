#include <stdio.h>
struct stu{
    char a[100];
    int m1,m2,m3;
    int tot;
}s[100];
int main()
{
    int i,n,j,r=1;
    scanf("%d",&n);
    r=n;
    for(i=1;i<=n;i++){
        scanf("%s%d%d%d",s[i].a,&s[i].m1,&s[i].m2,&s[i].m3);
        s[i].tot=s[i].m1+s[i].m2+s[i].m3;
    }
    for(i=1;i<=n;i++){
        for(j=1,r=1;j<=n;j++){
            if(s[i].tot<s[j].tot){
                r++;
            }
        }
        printf("%s %d %d \n",s[i].a,s[i].tot,r);
    }

    return 0;
}
