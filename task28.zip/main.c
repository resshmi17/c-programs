#include <stdio.h>
void swap(int *p,int n)
{
    for(int i=0;i<n;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            if((p+i)>(p+j))
            {
                int t=*(p+i);
                (p+i)=(p+j);
                *(p+j)=t;
            }
        }
    }
}
int main()
{
     int n,a[100];
     scanf("%d",&n);
     for(int i=0;i<n;i++)
     {
         scanf("%d",&a[i]);
     }
       swap(a,n);
       for(int i=0;i<n;i++)
       {
         printf("%d ",a[i]);
       }
     }
