#include <stdio.h>
int power(int a,int b);
int main()
{
    int a,b,c,d=0;
    scanf("%d",&a);
    for(b=a,c=1;b>9;b=b/10,c++);
    b=a;
    while(b)
    {
        d=d+power((b%10),c);
        b=b/10;
    }
    printf(a==d?"Armstrong":"Not an Armstrong");    
    return 0;
}

int power(int a,int b)
{
    int c=1;
    for( ;b>=1;c=c*a,b--);
    return c;
}