/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int a=1,b=2,c=3,d=4,e,f,g,h;
e=a*b/c;
f=a*b%c+1;
g=++a*b-c--;
h=7- -b* ++d;
printf("%d %d %d %d",e,f,g,h);
}
