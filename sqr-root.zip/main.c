#include<stdio.h>

int main(){
     int n;
     float s,t=0;
     scanf("%d",&n);
     s=n/2;
     while(t!=s){
          t=s;
          s=(n/t+t)/2;
     }
     n=s;
     if(n==s)
     printf("%d",n);
     else
     printf("%.3f",s);
     return 0;
}