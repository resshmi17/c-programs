#include<stdio.h>
int main(){
int n,i,f;
scanf("%d",&n);
for(i=2,f=1;i<=n/2;i++)
{
    if(n%i==0){
        f=0;
        break;
    }
}
printf(f?"prime":"not prime");
}