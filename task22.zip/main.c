#include <stdio.h>
#include<string.h>
int main()
{
    char a[100],b[100][100],f[100],re[100];
    int i,r=0,c=0;
    scanf("%[^\n]",a);
    for(i=0;a[i];i++)
    {
    if(a[i]!=' ')
    b[r][c++]=a[i];
    else
    {
    b[r][c]=0;
    r++;c=0;
    }
    }
    b[r][c]=0;
    scanf("%s %s",f,re);
    for(i=0;i<=r;i++)
    {
    if(!strcmp(b[i],f))
    strcpy(b[i],re);
    printf("%s ",b[i]);
    }
    return 0;
}