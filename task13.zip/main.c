#include <stdio.h>
int main()
{
int a,i,j;
scanf("%d",&a);
for(i=1;a>=i;i++)
{
    for(j=1;a>=j;j++)
    {
        if(i==j||i+j==a+1)
        printf("%d",i);
        else
        printf(" ");
    }
    printf("\n");
}
    return 0;
}