#include <stdio.h>

int main()
{
int a,b;
scanf("%d %d",&a,&b);
switch(a!=b)
{
    case 1:if(a%b==0)
    printf("true1");
    else
    printf("false1");break;
    case 0:if(b%a==0)
    printf("true");
    else
    printf("false");
    break;
}
}