#include<stdio.h>
#include<string.h>
struct dept{
 char name[100];
 int password;
}s[100];
int main(){
 int n,p;
 char username[100],flag=0;
 scanf("%d",&n);
 for(int i=0;i<n;i++){
 scanf("%s %d",s[i].name,&s[i].password);
}
for(int i=0;i<n;i++){
 printf("name:%s\n password:%d\n",s[i].name,s[i].password);
}
 for(int j=0;j<n;j++){
  scanf("%s %d",username,&p);
  
  for(int i=0;i<n;i++){
   if(strcmp(s[i].name,username)==0 &&s[i].password==p){
   {
    flag=1;
   }
 }
}

    printf(flag==1?"login successfull":"invalid");
 }

}